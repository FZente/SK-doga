﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace téglalap.Model
{
    public class Rectangle
    {
        public double oldal1;
        public double oldal2;
        public double terulet;
        public double kerulet;
        public double atlo;

        public double Oldal1
        {
            get { return oldal1; }
            set { oldal1 = value; }
        }

        public double Oldal2
        {
            get { return oldal2; }
            set { oldal2 = value; }
        }

        public double Terulet
        {
            get
            {
                terulet = oldal1 * oldal2;
                return terulet;
            }
        }

        public double Kerulet
        {
            get
            {
                kerulet = 2*(oldal2 + oldal1);
                return kerulet;
            }
        }

        public double Atlo
        {
            get
            {
                atlo = Math.Round(Math.Sqrt(Math.Pow(oldal1, 2) + Math.Pow(oldal2, 2)));
                return atlo;
            }
        }
    }
}
