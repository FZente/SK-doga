﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using téglalap.Model;
using System.Threading.Tasks;
using ViewModels.BaseClass;
using System.Windows;

namespace téglalap.ViewModel
{
    public class RectangelViewModel : ViewModelBase
    {
        public Rectangle r;
        public RelayCommand Calculate {  get; set; }
        public RelayCommand CloseWindow { get; set; }

        public RectangelViewModel() 
        {
            r = new Rectangle();
            Calculate = new RelayCommand(execute => Calc());
            CloseWindow = new RelayCommand(execute => Closewindow());
        }

        public double Oldal1
        {
            get { return r.Oldal1; }
            set { r.Oldal1 = value; }
        }

        public double Oldal2
        {
            get { return r.Oldal2; }
            set { r.Oldal2 = value; }
        }

        public double Terulet
        {
            get
            {
                return r.Terulet;
            }
        }

        public double Kerulet
        {
            get
            {
                return r.Kerulet;
            }
        }

        public double Atlo
        {
            get
            {
                return r.Atlo;
            }
        }

        public void Calc()
        {
            OnPropertyChanged("Kerulet");
            OnPropertyChanged("Terulet");
            OnPropertyChanged("Atlo");
        }

        public void Closewindow()
        {
            Application.Current.MainWindow.Close();
        }
    }
}
