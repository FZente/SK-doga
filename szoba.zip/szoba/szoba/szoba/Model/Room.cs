﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szoba.Model
{
    internal class Room
    {
        public int fal1;
        public int fal2;
        public int munkadij;
        public int festek;
        public int vegosszeg;

        public int Fal1
        {
            get { return fal1; }
            set { fal1 = value; }
        }

        public int Fal2
        {
            get { return fal2; }
            set { fal2 = value; }
        }

        public int Munkadij
        {
            get { return munkadij; }
            set { munkadij = value; }
        }

        public int Festek
        {
            get { return festek; }
            set { festek = value; }
        }

        public int Vegosszeg
        {
            get
            {
                int falterulet = 4 * (fal1 * fal2);
                vegosszeg = falterulet * festek * munkadij;
                return vegosszeg;
            }
        }
    }
}
