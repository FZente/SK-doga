﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using szoba.Model;
using ViewModels.BaseClass;

namespace szoba.ViewModel
{
    public class RoomViewModel:ViewModelBase
    {
        public Room r;
        public RelayCommand Calculate {  get; set; }

        public RoomViewModel()
        {
            r = new Room();
            Calculate = new RelayCommand(execute => Calc())
        }
        public int Fal1
        {
            get { return r.Fal1; }
            set { r.Fal1 = value; }
        }

        public int Fal2
        {
            get { return r.Fal2; }
            set { r.Fal2 = value; }
        }

        public int Munkadij
        {
            get { return r.Munkadij; }
            set { r.Munkadij = value; }
        }

        public int Festek
        {
            get { return r.Festek; }
            set { r.Festek = value; }
        }

        public int Vegosszeg
        {
            get
            {
                return r.Vegosszeg;
            }
        }

        public void Calc()
        {
            OnPropertyChanged("Vegosszeg");
        }
    }
}
