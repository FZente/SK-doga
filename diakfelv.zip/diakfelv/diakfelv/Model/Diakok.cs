﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace diakfelv.Model
{
    public class Diakok
    {
        public string diakneve;
        public double infoPontszam;
        public double matekPontszam;
        public double osszPontszam;
        public double atlagPontszam;
        public string felvett = "";

        public string Neve
        {
            get { return diakneve; }
            set { diakneve = value; }
        }

        public double Inf
        {
            get { return infoPontszam; }
            set { infoPontszam = value; }
        }

        public double Mat
        {
            get { return matekPontszam; }
            set { matekPontszam = value; }
        }

        public double Ossz
        {
            get
            {
                osszPontszam = (matekPontszam + infoPontszam);
                return osszPontszam;
            }
        }

        public double Atlag
        {
            get 
            {
                atlagPontszam = osszPontszam / 2;
                return atlagPontszam; 
            }
        }

        public string Felv
        {
            get 
            {
                if (osszPontszam > 70)
                {
                    felvett = (diakneve + " felvételt nyert");
                }
                else
                {
                    felvett = (diakneve + " nem nyert felvételt");
                }
                return felvett; 
            }
        }
    }
}
