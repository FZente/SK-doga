﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using diakfelv.Model;
using System.Windows;
using ViewModels.BaseClass;

namespace diakfelv.ViewModel
{
    public class DiakokViewmodel: ViewModelBase
    {
        public Diakok d;

        public RelayCommand Calculate { get; set; }

        public RelayCommand CloseWindow { get; set; }

        public DiakokViewmodel() 
        {
            d = new Diakok();
            Calculate = new RelayCommand(execute => Calc());
            CloseWindow = new RelayCommand(execute => Closewindow());
        }

        public string Neve
        {
            get { return d.Neve; }
            set { d.Neve = value; }
        }

        public double Inf
        {
            get { return d.Inf; }
            set { d.Inf = value; }
        }

        public double Mat
        {
            get { return d.Mat; }
            set { d.Mat = value; }
        }

        public double Ossz
        {
            get
            {
                return d.Ossz;
            }
        }

        public double Atlag
        {
            get
            {
                return d.Atlag;
            }
        }

        public string Felv
        {
            get
            {
                return d.Felv;
            }
        }

        public void Calc()
        {
            OnPropertyChanged("Ossz");
            OnPropertyChanged("Atlag");
            OnPropertyChanged("Felv");
        }

        public void Closewindow()
        {
            Application.Current.MainWindow.Close();
        }
    }
}
