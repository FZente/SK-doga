﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using termekek.Model;
using ViewModels.BaseClass;
using System.Windows;

namespace termekek.ViewModel
{
    public class ProductViewModel:ViewModelBase
    {
        public Product p;
        public RelayCommand Calculate {  get; set; }
        public RelayCommand CloseWindow { get; set; }

        public ProductViewModel()
        {
            p = new Product();
            Calculate = new RelayCommand(execute => Calc());
            CloseWindow = new RelayCommand(execute => Closewindow());
        }

        public string Termek
        {
            get
            {
                return p.Termek;
            }
            set
            {
                p.Termek = value;
            }
        }
        public double Ar
        {
            get
            {
                return p.Ar;
            }
            set
            {
                p.Ar = value;
            }
        }

        public double Mennyiseg
        {
            get
            {
                return p.Mennyiseg;
            }
            set
            {
                p.Mennyiseg = value;
            }
        }

        public double Netto
        {
            get
            {
                return p.Netto;
            }
        }

        public double Afa
        {
            get
            {
                return p.Afa;
            }
        }

        public double Vegosszeg
        {
            get
            {
                return p.Vegosszeg;
            }
        }

        public void Calc()
        {
            OnPropertyChanged("Netto");
            OnPropertyChanged("Afa");
            OnPropertyChanged("Vegosszeg");
        }

        public void Closewindow()
        {
            Application.Current.MainWindow.Close();
        }
    }
}
