﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace termekek.Model
{
    public class Product
    {
        public string termeknev = "Kérem a termék nevét!";
        public double ar;
        public double mennyiseg;
        public double netto;
        public double afa;
        public double vegosszeg;

        public string Termek
        {
            get
            {
                return termeknev;
            }
            set
            {
                termeknev = value;
            }
        }
        public double Ar
        {
            get
            {
                return ar;
            }
            set
            {
                ar = value;
            }
        }

        public double Mennyiseg
        {
            get
            {
                return mennyiseg;
            }
            set
            {
                mennyiseg = value;
            }
        }

        public double Netto
        {
            get
            {
                netto = ar * mennyiseg;
                return netto;
            }
        }

        public double Afa
        {
            get
            {
                afa = Math.Round(ar * mennyiseg * 0.27, 2);
                return afa;
            }
        }

        public double Vegosszeg
        {
            get
            {
                vegosszeg = netto + afa;
                return vegosszeg;
            }
        }
    }
}
